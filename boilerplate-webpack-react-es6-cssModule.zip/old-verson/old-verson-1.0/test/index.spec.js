import { expect } from 'chai';
// import sinon from 'sinon';

describe('hello react spec', () => {
  it('works!', () => {
    expect(true).to.be.true;
  });
});