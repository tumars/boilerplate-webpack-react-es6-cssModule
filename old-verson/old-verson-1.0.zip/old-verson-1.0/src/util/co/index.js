const co = {
	fixNum(num) {
		return '+' + num
	}
}

export default co
